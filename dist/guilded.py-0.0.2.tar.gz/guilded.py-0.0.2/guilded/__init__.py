__title__ = 'guilded'
__author__ = 'shay'
__copyright__ = 'Copyright 2020 shay'
__version__ = '0.0.2'

from .__main__ import *