# guilded.py
Guilded API wrapper, written in Python

[![Documentation Status](https://readthedocs.org/projects/guildedpy/badge/?version=latest)](https://guildedpy.readthedocs.io/en/latest/?badge=latest)
